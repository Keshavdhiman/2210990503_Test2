//
//  Food.swift
//  2210990503_test2
//
//  Created by student-2 on 23/11/24.
//

import UIKit


struct Food {
    var name: String
    var calories: Int
    var foodType: String
    var image: UIImage?
    var preparationTime : Int
}



