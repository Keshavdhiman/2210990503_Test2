//
//  ViewController.swift
//  2210990503_test2
//
//  Created by student-2 on 23/11/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

